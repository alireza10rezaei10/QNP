from qnp import Database, Physics
