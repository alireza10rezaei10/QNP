from qnp.Database.RefractiveIndexDatabase.RefractiveIndexDatabase import (
    RefractiveIndexDatabase,
)
